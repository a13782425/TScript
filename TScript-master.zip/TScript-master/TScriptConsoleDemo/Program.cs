﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Reflection;
using TScript.Compiler;

namespace TScriptConsoleDemo
{
    static public class Program
    {
        static void Main(string[] args)
        {
            string str = File.ReadAllText("../../Test/Test.t");
            Console.WriteLine(str);
            TScriptCompiler tsc = new TScriptCompiler();
            if (tsc.Lexer(str))
            {

            }
            Console.ReadKey();
        }
    }

}
