﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// 保留字
    /// </summary>
    internal class ReservedWord
    {
        #region 修饰符

        /// <summary>
        /// internal
        /// </summary>
        internal const string INTERNAL_WORD = "internal";
        /// <summary>
        /// public
        /// </summary>
        internal const string PUBLIC_WORD = "public";
        /// <summary>
        /// private
        /// </summary>
        internal const string PRIVATE_WORD = "private";
        #endregion

        /// <summary>
        /// class
        /// </summary>
        internal const string CLASS_WORLD = "class";

        /// <summary>
        /// Using
        /// </summary>
        internal const string USING_WORD = "using";
        /// <summary>
        /// String
        /// </summary>
        internal const string STRING_WORD = "string";
        /// <summary>
        /// int
        /// </summary>
        internal const string INT32_WORD = "int";
        /// <summary>
        /// void
        /// </summary>
        internal const string VOID_WORD = "void";
    }
}
