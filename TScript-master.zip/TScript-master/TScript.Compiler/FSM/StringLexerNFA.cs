﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    internal class StringLexerNFA : LexerNFABase
    {
        public StringLexerNFA(TScriptLexer currentlexer)
            : base(currentlexer)
        {
        }
        internal override LexState CurrentLexState
        {
            get { return LexState.String; }
        }

        internal override void Execute(char ch, ref LexerModel lexerModel)
        {
            if (ch != '\"')
            {
                this.CurrentLexer.CurrentStrToken += ch;
            }
            else
            {
                lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.String, this.CurrentLexer.CurrentStrToken));
                this.CurrentLexer.CurrentStrToken = "";
                this.CurrentLexer.CurrentLexState = LexState.None;
            }
        }
    }
}
