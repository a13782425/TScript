﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    internal class IdentifierLexerNFA : LexerNFABase
    {
        public IdentifierLexerNFA(TScriptLexer currentlexer)
            : base(currentlexer)
        {
        }


        internal override LexState CurrentLexState
        {
            get { return LexState.Identifier; }
        }

        internal override void Execute(char ch, ref LexerModel lexerModel)
        {
            if (IsIdentifier(ch))
            {
                this.CurrentLexer.CurrentStrToken += ch;
            }
            else
            {
                switch (this.CurrentLexer.CurrentStrToken)
                {
                    case ReservedWord.USING_WORD:
                        this.CurrentLexer.CurrentLexState = LexState.None;
                        if (this.CurrentLexer.CacheLexState != LexState.None)
                        {
                            this.CurrentLexer.ThrowException("出现多个using");
                        }
                        this.CurrentLexer.CacheLexState = LexState.Using;
                        this.CurrentLexer.CurrentStrToken = "";
                        break;
                    case ReservedWord.PUBLIC_WORD:
                    case ReservedWord.INTERNAL_WORD:
                        lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.Modifier, this.CurrentLexer.CurrentStrToken));
                        break;
                    case ReservedWord.CLASS_WORLD:
                        this.CurrentLexer.CurrentLexState = LexState.None;
                        if (this.CurrentLexer.CacheLexState != LexState.None)
                        {
                            this.CurrentLexer.ThrowException("出现多个Class");
                        }
                        this.CurrentLexer.CacheLexState = LexState.Class;
                        this.CurrentLexer.CurrentStrToken = "";
                        break;
                    default:
                        //如果下一个字符是IsIdentifier 的 ，那么则认为这是一个变量或者方法的返回值或者类型
                        lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.Identifier, this.CurrentLexer.CurrentStrToken));
                        this.CurrentLexer.CurrentStrToken = "";
                        this.CurrentLexer.CurrentLexState = LexState.None;
                        break;
                }
                this.CurrentLexer.UndoChar();
            }
        }
    }
}
