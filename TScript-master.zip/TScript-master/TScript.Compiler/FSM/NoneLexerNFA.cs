﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    internal class NoneLexerNFA : LexerNFABase
    {
        public NoneLexerNFA(TScriptLexer currentlexer)
            : base(currentlexer)
        {
        }
        internal override LexState CurrentLexState
        {
            get { return LexState.None; }
        }

        internal override void Execute(char ch, ref LexerModel lexerModel)
        {
            this.CheckChar(ch, ref lexerModel);
        }
    }
}
