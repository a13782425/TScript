﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    internal class ClassLexerNFA : LexerNFABase
    {
        public ClassLexerNFA(TScriptLexer currentlexer)
            : base(currentlexer)
        {

        }
        internal override LexState CurrentLexState
        {
            get { return LexState.Class; }
        }

        internal override void Execute(char ch, ref LexerModel lexerModel)
        {
            if (IsIdentifier(ch))
            {
                this.CurrentLexer.CurrentStrToken += ch;
            }
            else
            {
                if (ch == '\n')
                {
                    char f = '0';
                    if (!this.CurrentLexer.EndOfSource)
                    {
                        f = this.CurrentLexer.ReadChar();
                    }
                    else
                    {
                        this.CurrentLexer.ThrowException("类名后错误！");
                    }
                    if (f != '{')
                    {
                        this.CurrentLexer.ThrowException("类名后错误！");
                    }
                    else
                    {
                        lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.Class, this.CurrentLexer.CurrentStrToken));
                        lexerModel.IsHaveMainBody = true;
                        this.CurrentLexer.CurrentStrToken = "";
                        this.CurrentLexer.CurrentLexState = LexState.None;
                        this.CurrentLexer.CacheLexState = LexState.None;
                    }
                }
                this.CurrentLexer.UndoChar();
            }
        }
    }
}
