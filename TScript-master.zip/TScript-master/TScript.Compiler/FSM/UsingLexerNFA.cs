﻿using System;
using System.Collections.Generic;
using System.Text;
using TScript.Utils;

namespace TScript.Compiler
{
    internal class UsingLexerNFA : LexerNFABase
    {
        public UsingLexerNFA(TScriptLexer currentlexer)
            : base(currentlexer)
        {
        }


        internal override LexState CurrentLexState
        {
            get { return LexState.Using; }
        }

        internal override void Execute(char ch, ref LexerModel lexerModel)
        {
            if (Char.IsLetter(ch))
            {
                this.CurrentLexer.CurrentStrToken += ch;
            }
            else
            {
                if (ch == '.')
                {
                    this.CurrentLexer.CurrentStrToken += ch;
                }
                else if (ch != ';')
                {
                    if (!Util.IsNullOrWhiteSpace(this.CurrentLexer.CurrentStrToken))
                    {
                        this.CurrentLexer.ThrowException("引用命名空间之间不能有空格！");
                    }
                }
                else
                {
                    lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.Using, this.CurrentLexer.CurrentStrToken));
                    this.CurrentLexer.CurrentStrToken = "";
                    this.CurrentLexer.CurrentLexState = LexState.None;
                    this.CurrentLexer.CacheLexState = LexState.None;
                    this.CurrentLexer.UndoChar();
                }

            }
        }
    }
}
