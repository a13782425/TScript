﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// NFA状态机基类
    /// </summary>
    internal abstract class LexerNFABase
    {
        internal abstract LexState CurrentLexState { get; }

        protected TScriptLexer CurrentLexer = null;

        public LexerNFABase(TScriptLexer currentlexer)
        {
            if (currentlexer == null)
            {
                throw new LexerException("NFA状态机初始化失败！！！");
            }
            CurrentLexer = currentlexer;
            CurrentLexer.NFADic.Add(CurrentLexState, this);
        }
        internal abstract void Execute(char ch, ref LexerModel lexerModel);

        /// <summary>
        /// 解析一个字符
        /// </summary>
        /// <param name="list"></param>
        protected void CheckChar(Char ch, ref LexerModel lexerModel)
        {
            switch (ch)
            {
                case ' ':
                case '\t':
                case '\n':
                case '\r':
                    break;
                case '{':
                    Token leftBrace = this.CurrentLexer.CreateToken(TokenType.LeftBrace, '{');
                    this.CurrentLexer.TokenStack.Push(leftBrace);
                    lexerModel.TokenList.Add(leftBrace);
                    break;
                case '}':
                    if (this.CurrentLexer.TokenStack.Count == 0)
                    {
                        this.CurrentLexer.ThrowException("此处多来一个\"}\"！！！");
                    }
                    Token rightBrace = this.CurrentLexer.CreateToken(TokenType.RightBrace);
                    Token rightBraceTemp = this.CurrentLexer.TokenStack.Pop();
                    if (rightBraceTemp.Type != TokenType.LeftBrace)
                    {
                        this.CurrentLexer.ThrowException("此处多来一个\"}\"！！！");
                    }
                    else
                    {
                        lexerModel.TokenList.Add(rightBrace);
                    }
                    break;
                case '[':
                    Token leftBracket = this.CurrentLexer.CreateToken(TokenType.LeftBracket);
                    this.CurrentLexer.TokenStack.Push(leftBracket);
                    lexerModel.TokenList.Add(leftBracket);
                    break;
                case ']':
                    if (this.CurrentLexer.TokenStack.Count == 0)
                    {
                        this.CurrentLexer.ThrowException("此处多来一个\"]\"！！！");
                    }
                    Token rightBracket = this.CurrentLexer.CreateToken(TokenType.RightBracket);
                    Token rightBracketTemp = this.CurrentLexer.TokenStack.Pop();
                    if (rightBracketTemp.Type != TokenType.LeftBracket)
                    {
                        this.CurrentLexer.ThrowException("此处多来一个\"]\"！！！");
                    }
                    else
                    {
                        lexerModel.TokenList.Add(rightBracket);
                    }
                    break;
                case '(':
                    Token leftPar = this.CurrentLexer.CreateToken(TokenType.LeftPar);
                    this.CurrentLexer.TokenStack.Push(leftPar);
                    lexerModel.TokenList.Add(leftPar);
                    break;
                case ')':
                    if (this.CurrentLexer.TokenStack.Count == 0)
                    {
                        this.CurrentLexer.ThrowException("此处多来一个\")\"！！！");
                    }
                    Token rightPar = this.CurrentLexer.CreateToken(TokenType.RightPar);
                    Token rightParTemp = this.CurrentLexer.TokenStack.Pop();
                    if (rightParTemp.Type != TokenType.LeftPar)
                    {
                        this.CurrentLexer.ThrowException("此处多来一个\")\"！！！");
                    }
                    else
                    {
                        lexerModel.TokenList.Add(rightPar);
                    }
                    break;
                case ';':
                    lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.SemiColon));
                    break;
                case ':':
                    lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.Colon));
                    break;
                case '.':
                    lexerModel.TokenList.Add(this.CurrentLexer.CreateToken(TokenType.Period));
                    break;
                case '\"':
                    this.CurrentLexer.CurrentLexState = LexState.String;
                    break;
                default:
                    if (IsIdentifier(ch))
                    {
                        switch (this.CurrentLexer.CacheLexState)
                        {
                            case LexState.Using:
                                this.CurrentLexer.CurrentLexState = LexState.Using;
                                this.CurrentLexer.CurrentStrToken += ch;
                                break;
                            case LexState.Class:
                                this.CurrentLexer.CurrentLexState = LexState.Class;
                                this.CurrentLexer.CurrentStrToken += ch;
                                break;
                            default:
                                this.CurrentLexer.CurrentLexState = LexState.Identifier;
                                this.CurrentLexer.CurrentStrToken += ch;
                                break;
                        }

                    }
                    else
                    {
                        this.CurrentLexer.ThrowInvalidCharacterException(ch);
                    }
                    break;
            }
        }

        /// <summary>
        /// 是否是有效的字符
        /// </summary>
        /// <param name="ch"></param>
        /// <returns></returns>
        protected bool IsIdentifier(char ch)
        {
            return (ch == '_' || Char.IsLetterOrDigit(ch));
        }
    }
}
