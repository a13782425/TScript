﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    internal class ParseClassModel
    {
    }
}
