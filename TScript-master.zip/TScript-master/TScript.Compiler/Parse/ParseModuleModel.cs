﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// 模块参数
    /// </summary>
    internal class ParseModuleModel
    {

    }
}
