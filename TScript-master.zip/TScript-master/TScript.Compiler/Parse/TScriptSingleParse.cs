﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// 对单一的LexerModel 进行加工，方便后期组合加工
    /// </summary>
    internal class TScriptSingleParse
    {
        private string _assemblyName;
        private LexerModel _lexerModel;

        public TScriptSingleParse(string assemblyName, LexerModel lexerModel)
        {
            this._assemblyName = assemblyName;
            this._lexerModel = lexerModel;
        }


        internal SingleParseModel GetSingleParseModel()
        {
            SingleParseModel singleParseModel = new SingleParseModel();

            return singleParseModel;
        }
    }
}
