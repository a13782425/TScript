﻿using System;
using System.Collections.Generic;
using System.Text;
using TScript.Model.Binary;

namespace TScript.Compiler
{
    public sealed class CompilerConfig
    {
        private string _assemblyName = "DefaultAssemblyName";
        /// <summary>
        /// 默认程序集名称
        /// </summary>
        public string AssmblyName { get { return _assemblyName; } set { _assemblyName = value; } }

        private string _defaultNamespaceName = "DefaultNamespaceName";
        /// <summary>
        /// 默认程序集名称
        /// </summary>
        public string DefaultNamespaceName { get { return _defaultNamespaceName; } set { _defaultNamespaceName = value; } }

        private byte[] _cacheCompilerBinary = null;
        /// <summary>
        /// 缓存编译的二进制流        
        /// </summary>
        internal byte[] CacheCompilerBinary { get { return _cacheCompilerBinary; } set { _cacheCompilerBinary = value; } }

        private bool _isCompiler = false;
        /// <summary>
        /// 是否正在编译
        /// </summary>
        public bool IsCompiler { get { return _isCompiler; } internal set { _isCompiler = value; } }

        private bool _isCompilerEnd = true;
        /// <summary>
        /// 是否编译完成
        /// </summary>
        public bool IsCompilerEnd { get { return _isCompilerEnd; } internal set { _isCompilerEnd = value; } }

        private AssemblyBinary _currentAssemblyBinary = null;
        /// <summary>
        /// 程序集数据
        /// </summary>
        public AssemblyBinary CurrentAssemblyBinary { get { return _currentAssemblyBinary; } internal set { _currentAssemblyBinary = value; } }

        private AssemblyMetadata _currentAssemblyMetadata = null;
        /// <summary>
        /// 元数据
        /// </summary>
        public AssemblyMetadata CurrentAssemblyMetadata { get { return _currentAssemblyMetadata; } internal set { _currentAssemblyMetadata = value; } }
    }
}
