﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    internal class SingleParseModel
    {
        private List<string> _usingList = new List<string>();
        internal List<string> UsingList { get { return _usingList; } }

        //private 

    }
}
