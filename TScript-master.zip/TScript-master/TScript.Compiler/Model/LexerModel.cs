﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    internal class LexerModel
    {
        internal string FileName { get; set; }
        /// <summary>
        /// 是否存在主体
        /// </summary>
        internal bool IsHaveMainBody { get; set; }
        /// <summary>
        /// 解析出来的脚本表征
        /// </summary>
        internal List<Token> TokenList { get; set; }
    }
}
