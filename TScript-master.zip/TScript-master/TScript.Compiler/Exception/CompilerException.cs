﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// 编译异常
    /// </summary>
    public class CompilerException : System.Exception
    {
        public CompilerException(String strMessage) : base(strMessage) { }
    }
}
