﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// 解析异常
    /// </summary>
    public class LexerException : System.Exception
    {
        public LexerException(String strMessage) : base(strMessage) { }
    }
}
