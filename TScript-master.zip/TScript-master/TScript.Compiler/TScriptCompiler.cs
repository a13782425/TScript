﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using TScript.Utils;

namespace TScript.Compiler
{
    public sealed class TScriptCompiler
    {
        #region 构造和字段

        private CompilerConfig _currentConfig = null;

        /// <summary>
        /// 编译配置
        /// </summary>
        public CompilerConfig CurrentConfig { get { return _currentConfig; } }

        public TScriptCompiler()
        {
            _currentConfig = new CompilerConfig();
            this.CurrentConfig.CurrentAssemblyBinary = new Model.Binary.AssemblyBinary();
            this.CurrentConfig.CurrentAssemblyMetadata = new Model.Binary.AssemblyMetadata();
        }

        #endregion

        public bool Lexer(string context, string assemblyName = null)
        {
            if (Util.IsNullOrWhiteSpace(context))
            {
                throw new CompilerException("上下文文本为空！！！");
            }
            if (Util.IsNullOrWhiteSpace(assemblyName))
            {
                assemblyName = CurrentConfig.AssmblyName;
            }

            CurrentConfig.IsCompiler = true;
            CurrentConfig.IsCompilerEnd = false;
            TScriptLexer tscriptLexer = new TScriptLexer(context, assemblyName);
            LexerModel lexerModel = tscriptLexer.GetLexerModel();
            TScriptSingleParse tscriptSingleParse = new TScriptSingleParse(assemblyName,lexerModel);
            SingleParseModel single = tscriptSingleParse.GetSingleParseModel();
            return true;
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="path">文件夹路径</param>
        /// <returns></returns>
        public bool Save(string path)
        {
            if (CurrentConfig.CacheCompilerBinary == null)
            {
                throw new CompilerException("请先执行Compiler！！！");
            }
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            return true;
        }
    }
}
