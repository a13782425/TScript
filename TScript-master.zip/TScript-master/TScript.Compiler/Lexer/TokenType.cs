﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// 脚本的表征类型
    /// </summary>
    internal enum TokenType
    {
        /// <summary>
        /// 空类型（没有实际用途）
        /// </summary>
        None = 0,
        /// <summary>
        /// {
        /// </summary>
        LeftBrace,
        /// <summary>
        /// }
        /// </summary>
        RightBrace,
        /// <summary>
        /// (
        /// </summary>
        LeftPar,
        /// <summary>
        /// )
        /// </summary>
        RightPar,
        /// <summary>
        /// [
        /// </summary>
        LeftBracket,
        /// <summary>
        /// ]
        /// </summary>
        RightBracket,
        /// <summary>
        /// .
        /// </summary>
        Period,
        /// <summary>
        /// :
        /// </summary>
        Colon,
        /// <summary>
        /// ;
        /// </summary>
        SemiColon,
        /// <summary>
        /// 说明符
        /// </summary>
        Identifier,
        /// <summary>
        /// 引用
        /// </summary>
        Using,
        /// <summary>
        /// 修饰符
        /// </summary>
        Modifier,
        /// <summary>
        /// 类
        /// </summary>
        Class,
        /// <summary>
        /// 字符串
        /// </summary>
        String,

    }
}
