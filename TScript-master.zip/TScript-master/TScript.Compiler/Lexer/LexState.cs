﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Compiler
{
    /// <summary>
    /// 解析状态
    /// </summary>
    internal enum LexState
    {
        /// <summary> 
        /// 没有关键字 
        /// </summary>
        None = 0,
        /// <summary> 
        /// 描述符 
        /// </summary>
        Identifier,
        /// <summary>
        /// 添加引用
        /// </summary>
        Using,
        /// <summary>
        /// 类
        /// </summary>
        Class,
        /// <summary>
        /// 字符串
        /// </summary>
        String,
    }
}
