﻿using System;
using System.Collections.Generic;
using System.Text;
using TScript.Utils;

namespace TScript.Compiler
{
    /// <summary>
    /// 解析字符串
    /// </summary>
    internal class TScriptLexer
    {
        /// <summary>
        /// 上下文
        /// </summary>
        private string _context;
        /// <summary>
        /// 程序集名称
        /// </summary>
        private string _assemblyName;
        /// <summary>
        /// 状态机集合
        /// </summary>
        private Dictionary<LexState, LexerNFABase> _nfaDic;
        /// <summary>
        /// 状态机集合
        /// </summary>
        internal Dictionary<LexState, LexerNFABase> NFADic { get { return _nfaDic; } }
        /// <summary>
        /// 当前要解析的所有行
        /// </summary>
        private List<String> _currentSourceLines;
        /// <summary>
        /// 当前解析行数
        /// </summary>
        private int _currentLineNum = 0;
        /// <summary>
        /// 当前解析的字符位置
        /// </summary>
        private int _currentCharNum = 0;
        /// <summary>
        /// 当前字符
        /// </summary>
        private char _currentChar = '0';
        /// <summary>
        /// 当前字符串Token
        /// </summary>
        internal String CurrentStrToken = null;
        /// <summary>
        /// 当前是否解析到最后一行
        /// </summary>
        internal bool EndOfSource { get { return _currentLineNum >= _currentSourceLines.Count; } }
        /// <summary>
        /// 是否到行尾巴
        /// </summary>
        internal bool EndOfLine { get { return _currentCharNum >= _currentSourceLines[_currentLineNum].Length; } }

        /// <summary>
        /// 缓存解析状态
        /// </summary>
        private LexState _cacheLexState = LexState.None;
        internal LexState CacheLexState { get { return _cacheLexState; } set { _cacheLexState = value; } }

        private LexState _currentLexState = LexState.None;
        /// <summary>
        /// 当前解析状态
        /// </summary>
        internal LexState CurrentLexState { get { return _currentLexState; } set { _currentLexState = value; if (_currentLexState == LexState.None) { CurrentStrToken = ""; } } }

        private Stack<Token> _tokenStack = null;
        /// <summary>
        /// 括号的堆栈
        /// </summary>
        internal Stack<Token> TokenStack { get { return _tokenStack; } }


        internal TScriptLexer(string context, string assemblyName)
        {
            this._context = context;
            this._assemblyName = assemblyName;
            string[] strLines = _context.Split(new char[] { '\r', '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
            _currentSourceLines = new List<string>();
            foreach (String strLine in strLines)
                _currentSourceLines.Add(strLine + '\n');
            _nfaDic = new Dictionary<LexState, LexerNFABase>();
            _tokenStack = new Stack<Token>();
            SolverLexerNFA();
        }


        internal LexerModel GetLexerModel()
        {
            LexerModel lexerModel = new LexerModel();
            _currentLineNum = 0;
            _currentCharNum = 0;
            CurrentLexState = LexState.None;
            TokenStack.Clear();
            lexerModel.TokenList = new List<Token>();
            lexerModel.IsHaveMainBody = false;
            while (!EndOfSource)
            {
                if (EndOfLine)
                {
                    IgnoreLine();
                    continue;
                }
                _currentChar = ReadChar();
                if (NFADic.ContainsKey(CurrentLexState))
                {
                    NFADic[CurrentLexState].Execute(_currentChar, ref lexerModel);
                }
                else
                {
                    ThrowException("没有找到对应的" + CurrentLexState.ToString() + "的NFA");
                }
            }
            return lexerModel;
        }
        #region 私有



        /// <summary>
        /// 转向下一行
        /// </summary>
        private void IgnoreLine()
        {
            ++_currentLineNum;
            _currentCharNum = 0;
        }
        /// <summary>
        /// 读取字符
        /// </summary>
        /// <returns></returns>
        internal char ReadChar()
        {
            if (EndOfSource)
                throw new LexerException("End of source reached.");
            char ch = _currentSourceLines[_currentLineNum][_currentCharNum++];
            if (EndOfLine)
            {
                IgnoreLine();
            }
            return ch;
        }

        /// <summary>
        /// 回退一个字符
        /// </summary>
        internal void UndoChar()
        {
            if (_currentLineNum == 0 && _currentCharNum == 0)
                throw new LexerException("Cannot undo char beyond start of source.");
            --_currentCharNum;
            if (_currentCharNum < 0)
            {
                --_currentLineNum;
                _currentCharNum = _currentSourceLines[_currentLineNum].Length - 1;
            }
        }

        /// <summary>
        /// 创建Token
        /// </summary>
        /// <param name="tokenType"></param>
        /// <returns></returns>
        internal Token CreateToken(TokenType tokenType)
        {
            return CreateToken(tokenType, _currentChar);
        }
        /// <summary>
        /// 创建Token
        /// </summary>
        /// <param name="tokenType"></param>
        /// <param name="lexeme"></param>
        /// <returns></returns>
        internal Token CreateToken(TokenType tokenType, object lexeme)
        {
            CurrentLexState = LexState.None;
            return new Token(tokenType, lexeme, _currentLineNum, _currentCharNum);
        }

        /// <summary>
        /// 无效字符异常
        /// </summary>
        /// <param name="ch"></param>
        internal void ThrowInvalidCharacterException(char ch)
        {
            throw new LexerException(this._assemblyName + ":" + (_currentLineNum + 1) + "  Unexpected character [" + ch + "]  Line:" + (_currentLineNum + 1) + " Column:" + _currentCharNum + " [" + _currentSourceLines[_currentLineNum] + "]");
        }

        /// <summary>
        /// 抛异常
        /// </summary>
        /// <param name="msg"></param>
        internal void ThrowException(string msg)
        {
            throw new LexerException("程序集：" + this._assemblyName + " is error,the lineNum is " + (_currentLineNum + 1) + ":" + msg);
        }

        private void SolverLexerNFA()
        {
            System.Reflection.Assembly assembly = this.GetType().Assembly;
            Type[] types = assembly.GetTypes();
            Type nfaType = typeof(LexerNFABase);
            for (int i = 0; i < types.Length; i++)
            {
                if (types[i].IsSubclassOf(nfaType) && !types[i].IsAbstract)
                {
                    Activator.CreateInstance(types[i], this);
                }
            }
        }

        #endregion
    }
}
