﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Runtime
{
    public static class RuntimeGlobal
    {
        private static bool _isRun = false;
        /// <summary>
        /// 是否在运行
        /// </summary>
        public static bool IsRun { get { return _isRun; } internal set { _isRun = value; } }

        private static int _runStackDepth = 1000;

        /// <summary>
        /// 运行时栈深度
        /// </summary>
        public static int RunStackDepth
        {
            get { return _runStackDepth; }
            set
            {
                if (IsRun)
                    throw new RuntimeException("运行时正在运行时无法更改参数！");
                _runStackDepth = value;
            }
        }

    }
}
