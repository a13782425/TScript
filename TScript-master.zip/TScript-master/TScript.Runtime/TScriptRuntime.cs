﻿using System;
using System.Collections.Generic;
using System.Text;
using TScript.Model.Runtime;
using TScript.Utils;

namespace TScript.Runtime
{
    public class TScriptRuntime
    {
        #region 单例

        private TScriptRuntime()
        {
            contextCacheDic = new Dictionary<string, TScriptContext>();
        }
        private TScriptRuntime _instance = null;
        public TScriptRuntime Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new TScriptRuntime();
                }
                return _instance;
            }
        }

        #endregion

        private readonly Dictionary<string, TScriptContext> contextCacheDic;

        

        /// <summary>
        /// 启动运行时
        /// </summary>
        /// <returns></returns>
        public bool Run(byte[] binary)
        {
            if (RuntimeGlobal.IsRun)
            {
                throw new Exception("重复启动运行时！");
            }
            if (LoadAssembly(binary))
            {
                RuntimeGlobal.IsRun = true;
                return true;
            }
            return false;
        }

        /// <summary>
        /// 执行
        /// </summary>
        /// <returns></returns>
        public bool Execute(RuntimeObject runtimeObj)
        {
            if (!RuntimeGlobal.IsRun)
            {
                throw new Exception("运行时没有启动！");
            }
            if (Util.IsNullOrWhiteSpace(runtimeObj.NamespaceName) || Util.IsNullOrWhiteSpace(runtimeObj.ClassName) || Util.IsNullOrWhiteSpace(runtimeObj.MethodName))
            {
                throw new Exception("RuntimeObject 参数有误！");
            }
            TScriptContext tc = null;
            if (contextCacheDic.ContainsKey(runtimeObj.ToString()))
            {
                tc = contextCacheDic[runtimeObj.ToString()];
            }
            else
            {
                tc = new TScriptContext();
                contextCacheDic.Add(runtimeObj.ToString(), tc);
            }
            return tc.Execute(runtimeObj);
        }



        private bool LoadAssembly(byte[] binary)
        {
            return true;
        }
    }
}
