﻿using System;
using System.Collections.Generic;
using System.Text;
using TScript.Model.Runtime;

namespace TScript.Runtime
{
    internal class TScriptContext
    {
        internal TScriptContext()
        {
            variableDic = new Dictionary<string, object>();
        }
        /// <summary>
        /// 变量列表
        /// </summary>
        private Dictionary<string, object> variableDic;

        private RuntimeObject _currentRuntimeObject;

        internal RuntimeObject CurrentRuntimeObject { get { return _currentRuntimeObject; } set { _currentRuntimeObject = value; } }

        internal bool Execute()
        {
            if (CurrentRuntimeObject.IsNull)
            {
                throw new RuntimeException("RuntimeObject is null");
            }
            return true;
        }

        internal bool Execute(RuntimeObject runtimeObj)
        {
            CurrentRuntimeObject = runtimeObj;
            return Execute();
        }
    }
}
