﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Runtime
{
    /// <summary>
    /// 运行时异常
    /// </summary>
    public class RuntimeException : System.Exception
    {
        public RuntimeException(String strMessage) : base(strMessage) { }
    }
}
