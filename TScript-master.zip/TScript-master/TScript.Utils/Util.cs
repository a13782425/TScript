﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Utils
{
    public sealed class Util
    {
        /// <summary>
        /// 指示指定字符串是否为null、空还是仅有空白字符组成
        /// </summary>
        /// <returns></returns>
        public static bool IsNullOrWhiteSpace(string value)
        {
            if (value == null)
            {
                return true;
            }
            for (int i = 0; i < value.Length; i++)
            {
                if (!char.IsWhiteSpace(value[i]))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 指示指定的 System.String 对象是 null 还是 System.String.Empty 字符串。
        /// </summary>
        /// <returns></returns>
        public static bool IsNullOrEmpty(string value)
        {
            return value == null || value.Length == 0;
        }
    }
}
