﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Model.Instruction
{
    /// <summary>
    /// 指令集
    /// </summary>
    public enum Opcode
    {
        /// <summary>
        /// 无操作占位符
        /// </summary>
        Nop,
        /// <summary>
        /// 推送对元数据中存储的字符串的新对象引用。
        /// </summary>
        Ldstr,
        /// <summary>
        /// 将栈上两个元素相加
        /// </summary>
        Add,
        /// <summary>
        /// 调用静态方法
        /// </summary>
        Call,
        /// <summary>
        /// 调用实例方法
        /// </summary>
        CallVirt,
    }
}
