﻿using System;
using System.Collections.Generic;
using System.Text;


namespace TScript.Model.Instruction
{
    [Serializable]
    public struct SingleInstruction
    {
        public Opcode CurrentOpcode;
        public object[] Args;
        public StackInfo.StackInfo CurrentStack;
    }
}
