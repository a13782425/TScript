﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Model.Binary
{
    [Serializable]
    public class AssemblyMetadata
    {
    }
}
