﻿using System;
using System.Collections.Generic;
using System.Text;
using TScript.Model.Instruction;

namespace TScript.Model.Binary
{
    [Serializable]
    public class ClassBinary
    {
        private string _name = "";

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private Stack<SingleInstruction> _instructionStack = new Stack<SingleInstruction>();
        public Stack<SingleInstruction> InstructionStack { get { return _instructionStack; } }

        private List<MethodBinary> _methodList = new List<MethodBinary>();

        public List<MethodBinary> MethodList
        {
            get { return _methodList; }
            set { _methodList = value; }
        }

    }
}
