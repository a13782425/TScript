﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Model.Binary
{
    [Serializable]
    public class ModuleBinary
    {
        private string _name = "";

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private List<ClassBinary> _classList = new List<ClassBinary>();

        public List<ClassBinary> ClassList
        {
            get { return _classList; }
            set { _classList = value; }
        }

    }
}
