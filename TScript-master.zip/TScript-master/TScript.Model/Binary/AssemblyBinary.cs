﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Model.Binary
{
    [Serializable]
    public class AssemblyBinary
    {
        private string _name = "";

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _createTime = "";

        public string CreateTime
        {
            get { return _createTime; }
            set { _createTime = value; }
        }

        private List<ModuleBinary> _moduleList = new List<ModuleBinary>();

        public List<ModuleBinary> ModuleList
        {
            get { return _moduleList; }
            set { _moduleList = value; }
        }

    }
}
