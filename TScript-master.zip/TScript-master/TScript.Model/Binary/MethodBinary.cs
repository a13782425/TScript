﻿using System;
using System.Collections.Generic;
using System.Text;
using TScript.Model.Instruction;

namespace TScript.Model.Binary
{
    [Serializable]
    public class MethodBinary
    {
        private string _namespaceName = "";
        public string NamespaceName { get { return _namespaceName; } set { _namespaceName = value; } }

        public string _className = "";
        public string ClassName { get { return _className; } set { _className = value; } }

        public string _methodName = "";
        public string MethodName { get { return _methodName; } set { _methodName = value; } }

        private Stack<SingleInstruction> _instructionStack = new Stack<SingleInstruction>();
        public Stack<SingleInstruction> InstructionStack { get { return _instructionStack; } }

    }
}
