﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Model.StackInfo
{
    /// <summary>
    /// 堆栈信息
    /// </summary>
    [Serializable]
    public struct StackInfo
    {
        /// <summary>
        /// 文件摘要
        /// </summary>
        public string Breviary;
        /// <summary>
        /// 起始关键字所在行数
        /// </summary>
        public int Line;
        public StackInfo(string breviary, int line)
        {
            Breviary = breviary;
            Line = line;
        }
    }
}
