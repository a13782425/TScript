﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Model.Runtime
{
    /// <summary>
    /// 运行时Obj
    /// </summary>
    public struct RuntimeObject
    {
        public readonly string NamespaceName;

        public readonly string ClassName;

        public readonly string MethodName;

        public RuntimeObject(string namespaceName, string className, string methodName)
        {
            this.NamespaceName = namespaceName;
            this.ClassName = className;
            this.MethodName = methodName;
        }
        public bool IsNull
        {
            get
            {
                return string.IsNullOrEmpty(this.NamespaceName) || string.IsNullOrEmpty(this.ClassName) || string.IsNullOrEmpty(this.MethodName);
            }
        }
        public String ToString()
        {
            return this.NamespaceName + this.ClassName;
        }
    }
}
