﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TScript.Model.Runtime
{
    /// <summary>
    /// 变量Obj
    /// </summary>
    public struct VariableObject
    {
        public readonly string VariableName;
        public object VariableValue;
        public readonly Type VariableType;

        public VariableObject(string variableName,object variableValue, Type variableType)
        {
            this.VariableName = variableName;
            this.VariableValue = variableValue;
            this.VariableType = variableType;
        }
    }
}
