﻿using System;

namespace TS.Core
{
    /// <summary>
    /// 修饰符枚举
    /// </summary>
    [Serializable]
    internal enum ModifierEnum : byte
    {
        /// <summary>
        /// 私有
        /// </summary>
        Private,
        /// <summary>
        /// 公共
        /// </summary>
        Public,
        /// <summary>
        /// 集成私有
        /// </summary>
        Protected,
        /// <summary>
        /// 程序集内部
        /// </summary>
        Internal
    }

    /// <summary>
    /// 基元类型枚举
    /// </summary>
    [Serializable]
    internal enum PrimitiveEnum : byte
    {
        /// <summary>
        /// 字符串
        /// </summary>
        String,
        /// <summary>
        /// 32位整型
        /// </summary>
        Int32,
        /// <summary>
        /// 64位整型
        /// </summary>
        Int64,
        /// <summary>
        /// 单精度
        /// </summary>
        Single,
        /// <summary>
        /// 双精度
        /// </summary>
        Double,
        /// <summary>
        /// 枚举
        /// </summary>
        Enum,
    }
}
