﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Core.Table
{
    /// <summary>
    /// 模块定义表
    /// </summary>
    public class ModuleDef
    {
        public string Id
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
