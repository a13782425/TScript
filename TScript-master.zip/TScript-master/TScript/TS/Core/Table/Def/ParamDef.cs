﻿using System;

namespace TS.Core.Table
{
    /// <summary>
    /// 参数定义表
    /// </summary>
    [Serializable]
    public class ParamDef
    {
        private string _id = "";
        /// <summary>
        /// Guid
        /// </summary>
        public string Id { get { return _id; } set { _id = value; } }

        private string _name = "";
        /// <summary>
        /// 名字
        /// </summary>
        public string Name { get { return _name; } set { _name = value; } }

        private string _typeId = "";
        /// <summary>
        /// 类型Id
        /// </summary>
        public string TypeId { get { return _typeId; } set { _typeId = value; } }

    }
}
