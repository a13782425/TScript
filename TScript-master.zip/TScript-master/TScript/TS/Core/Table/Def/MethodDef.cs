﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Core.Table
{
    /// <summary>
    /// 方法定义表
    /// </summary>
    public class MethodDef
    {
        public string Id
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
