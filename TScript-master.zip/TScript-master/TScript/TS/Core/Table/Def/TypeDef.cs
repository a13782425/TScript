﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Core.Table
{
    /// <summary>
    /// 类型定义表
    /// </summary>
    public class TypeDef
    {
        public string Id
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
