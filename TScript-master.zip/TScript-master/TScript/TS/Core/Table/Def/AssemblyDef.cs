﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Core.Table
{
    /// <summary>
    /// 程序集定义
    /// </summary>
    [Serializable]
    internal class AssemblyDef
    {
        private string id = "";

        /// <summary>
        /// Id
        /// </summary>
        public string Id { get { return id; } set { id = value; } }

        private string _name = "";

        /// <summary>
        /// 名称
        /// </summary>
        public string Name { get { return _name; } set { _name = value; } }

        private List<string> _moduleList = new List<string>();
        public List<string> ModuleList { get { return _moduleList; } }
    }
}
