﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Core.Table
{
    /// <summary>
    /// 程序集引用表
    /// </summary>
    public class AssemblyRef
    {
        public string Token
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string Version
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string Name
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
