﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Core.Table
{
    /// <summary>
    /// 字段引用表
    /// </summary>
    public class MemberRef
    {
    }
}
