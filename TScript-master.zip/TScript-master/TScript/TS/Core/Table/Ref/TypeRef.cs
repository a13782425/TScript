﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Core.Table
{
    /// <summary>
    /// 类型引用表
    /// </summary>
    public class TypeRef
    {
    }
}
