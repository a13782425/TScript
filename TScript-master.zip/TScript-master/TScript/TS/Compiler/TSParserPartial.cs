﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace TS.Compiler
{
    internal sealed partial class TSParser
    {
        /// <summary>
        /// 系统类型
        /// </summary>
        private class SystemType
        {
            public SystemType(Type type)
            {
                _currentType = type;
            }
            public string Name { get { return CurrentType.Name; } }

            public string FullName { get { return CurrentType.FullName; } }

            private Type _currentType = null;

            public Type CurrentType { get { return _currentType; } }

            public override string ToString()
            {
                return this.Name;
            }

            public static bool operator ==(SystemType s, string name)
            {
                return s.Name == name;
            }
            public static bool operator ==(SystemType s1, SystemType s2)
            {
                return s1.FullName == s2.FullName;
            }
            public static bool operator !=(SystemType s, string name)
            {
                return s.Name != name;
            }
            public static bool operator !=(SystemType s1, SystemType s2)
            {
                return s1.FullName != s2.FullName;
            }
        }

        /// <summary> 是否还有更多需要解析的语法 </summary>
        private bool HasMoreTokens()
        {
            return _allParserStack.Count > 0;
        }
        /// <summary>
        /// 加载程序集
        /// </summary>
        /// <param name="assembly"></param>
        internal void LoadSystemAssembly(Assembly assembly)
        {
            Type[] allType = assembly.GetTypes();
            foreach (Type item in allType)
            {
                SystemType st = new SystemType(item);
                string name = item.Namespace == null ? "Default" : item.Namespace;
                if (!AllAssemblyNameDic.ContainsKey(name))
                {
                    AllAssemblyNameDic.Add(name, new List<SystemType>());
                }
                AllAssemblyNameDic[name].Add(st);
            }
        }

    }
}
