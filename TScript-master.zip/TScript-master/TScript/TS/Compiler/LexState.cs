﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Compiler
{
    internal enum LexState
    {
        /// <summary> 没有关键字 </summary>
        None,
        /// <summary>引用</summary>
        Using,
        /// <summary> = 等于或者相等 </summary>
        AssignOrEqual,
        /// <summary> / 注释或者除号 </summary>
        CommentOrDivideOrAssignDivide,
        /// <summary> 行注释 </summary>
        LineComment,
        /// <summary> 区域注释开始 </summary>
        BlockCommentStart,
        /// <summary> 区域注释结束 </summary>
        BlockCommentEnd,
        /// <summary> .或者多参符(...) </summary>
        PeriodOrParams,
        /// <summary> 多参符(...) </summary>
        Params,
        /// <summary> + 或者 ++ 或者 += </summary>
        PlusOrIncrementOrAssignPlus,
        /// <summary> - 或者 -= </summary>
        MinusOrDecrementOrAssignMinus,
        /// <summary> * 或者 *= </summary>
        MultiplyOrAssignMultiply,
        /// <summary> % 或者 %= </summary>
        ModuloOrAssignModulo,
        /// <summary> & 或者 &= 或者 && </summary>
        AndOrCombine,
        /// <summary> | 或者 |= 或者 || </summary>
        OrOrInclusiveOr,
        /// <summary> ^ 或者 ^= </summary>
        XorOrAssignXor,
        /// <summary> << 或者 <<= </summary>
        ShiOrAssignShi,
        /// <summary> >> 或者 >>= </summary>
        ShrOrAssignShr,
        /// <summary> ! 非或者不等于 </summary>
        NotOrNotEqual,
        /// <summary> > 大于或者大于等于 </summary>
        GreaterOrGreaterEqual,
        /// <summary> < 小于或者小于等于 </summary>
        LessOrLessEqual,
        /// <summary> 字符串 双引号 单引号 字符串都可以</summary>
        String,
        /// <summary> \ 格式符 </summary>
        StringEscape,
        /// <summary> @ 开始字符串 </summary>
        SimpleStringStart,
        /// <summary> @" 不格式化的字符串 类似c# @符号 </summary>
        SimpleString,
        /// <summary> 字符串内出现"是引号还是结束符 </summary>
        SimpleStringQuotationMarkOrOver,
        /// <summary> ${} 格式化字符串 </summary>
        StringFormat,
        /// <summary> 十进制数字或者十六进制数字 </summary>
        NumberOrHexNumber,
        /// <summary> 十进制数字 </summary>
        Number,
        /// <summary> 十六进制数字 </summary>
        HexNumber,
        /// <summary> 描述符 </summary>
        Identifier,
    }
}
