﻿using System;
using System.Collections.Generic;
using System.Text;
using TS.Core;
using TS.Core.Table;
using TS.Exception;
using TScript.Utils;

namespace TS.Compiler
{
    /// <summary>
    /// 语法解析器，先解析在分析
    /// </summary>
    internal sealed partial class TSLexer
    {

        #region 单例

        /// <summary>
        /// 单例
        /// </summary>
        private TSLexer()
        {
            _allAssemblyDefDic = new Dictionary<string, AssemblyDef>();
        }
        private static TSLexer _instance = null;
        /// <summary>
        /// 唯一实例
        /// </summary>
        public static TSLexer Instance { get { if (_instance == null) _instance = new TSLexer(); return _instance; } }

        #endregion

        #region 属性和字段
        private string _content = "";
        private byte[] _bytes = null;
        /// <summary>
        /// 所有程序集的集合
        /// </summary>
        private Dictionary<string, AssemblyDef> _allAssemblyDefDic;
        /// <summary>
        /// 所有程序集的集合
        /// </summary>
        internal Dictionary<string, AssemblyDef> AllAssemblyDefDic { get { return _allAssemblyDefDic; } }

        #region 解析使用
        private string _currentAssemblyName = "";
        /// <summary>
        /// 当前要解析的所有行
        /// </summary>
        private List<String> _currentSourceLines;
        /// <summary>
        /// 当前解析行数
        /// </summary>
        private int _currentLineNum = 0;
        /// <summary>
        /// 当前解析的字符位置
        /// </summary>
        private int _currentCharNum = 0;
        /// <summary>
        /// 当前字符串Token
        /// </summary>
        private String _currentStrToken = null;
        /// <summary>
        /// 当前字符
        /// </summary>
        private char _currentChar = '0';
        /// <summary>
        /// 当前引用集合
        /// </summary>
        private List<string> _currentUsingList = new List<string>();
        /// <summary>
        /// 缓存解析状态
        /// </summary>
        private LexState _cacheLexState = LexState.None;

        private LexState _currentLexState = LexState.None;
        /// <summary>
        /// 当前解析状态
        /// </summary>
        private LexState CurrentLexState { get { return _currentLexState; } set { _currentLexState = value; if (_currentLexState == LexState.None) { _currentStrToken = ""; } } }
        /// <summary>
        /// 当前是否解析到最后一行
        /// </summary>
        private bool EndOfSource { get { return _currentLineNum >= _currentSourceLines.Count; } }
        /// <summary>
        /// 是否到行尾巴
        /// </summary>
        private bool EndOfLine { get { return _currentCharNum >= _currentSourceLines[_currentLineNum].Length; } }
        #endregion

        #endregion

        /// <summary>
        /// 解析
        /// </summary>
        /// <param name="assemblyName">程序集名称</param>
        /// <param name="content">内容</param>
        /// <returns></returns>
        public bool Lexer(string assemblyName, string content)
        {
            if (Util.IsNullOrWhiteSpace(assemblyName))
                throw new LexerException("名称为空！！！");
            string[] strLines = content.Split(new char[] { '\r', '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
            _currentSourceLines = new List<string>();
            foreach (String strLine in strLines)
                _currentSourceLines.Add(strLine);
            AssemblyDef assemblyDef = null;
            if (AllAssemblyDefDic.ContainsKey(assemblyName))
            {
                assemblyDef = AllAssemblyDefDic[assemblyName];
            }
            else
            {
                assemblyDef = new AssemblyDef();
                assemblyDef.Id = Guid.NewGuid().ToString();
                assemblyDef.Name = assemblyName;
                AllAssemblyDefDic.Add(assemblyName, assemblyDef);
            }
            _currentAssemblyName = assemblyName;
            List<Token> tokenList = GetTokens();
            TSParser.Instance.Parser(tokenList, ref assemblyDef);
            return true;
        }

        /// <summary>
        /// 获取Token
        /// </summary>
        /// <returns></returns>
        private List<Token> GetTokens()
        {
            List<Token> list = new List<Token>();
            _currentUsingList.Clear();
            _currentLineNum = 0;
            _currentCharNum = 0;
            CurrentLexState = LexState.None;
            while (!EndOfSource)
            {
                if (EndOfLine)
                {
                    IgnoreLine();
                    continue;
                }
                _currentChar = ReadChar();
                switch (CurrentLexState)
                {
                    case LexState.None:
                        CheckChar(ref list);
                        break;
                    case LexState.String:
                        if (_currentChar == '\"')
                        {
                            _cacheLexState = LexState.None;
                            list.Add(CreateToken(TokenType.String, _currentStrToken));
                        }
                        else if (_currentChar == '\\')
                        {
                            CurrentLexState = LexState.StringEscape;
                        }
                        else if (_currentChar == '\r' || _currentChar == '\n')
                        {
                            ThrowInvalidCharacterException(_currentChar);
                        }
                        else if (_currentChar == '$')
                        {
                            _cacheLexState = LexState.String;
                            CurrentLexState = LexState.StringFormat;
                        }
                        else
                        {
                            _currentStrToken += _currentChar;
                        }
                        break;
                    case LexState.PeriodOrParams:
                        if (_currentChar == '.')
                        {
                            CurrentLexState = LexState.Params;
                        }
                        else
                        {
                            list.Add(CreateToken(TokenType.Period, "."));
                            UndoChar();
                        }
                        break;
                    case LexState.Using:
                        if (_currentChar == ';')
                        {
                            list.Add(CreateToken(TokenType.Using, _currentStrToken));
                            CurrentLexState = LexState.None;
                            UndoChar();
                        }
                        else
                        {
                            CheckChar(ref list);
                        }
                        break;
                    case LexState.Identifier:
                        if (IsIdentifier(_currentChar))
                        {
                            _currentStrToken += _currentChar;
                        }
                        else
                        {
                            TokenType tokenType;
                            switch (_currentStrToken)
                            {
                                case ReservedWord.USING_WORD:
                                    tokenType = TokenType.Using;
                                    CurrentLexState = LexState.Using;
                                    break;
                                default:
                                    tokenType = TokenType.Identifier;
                                    break;
                            }
                            switch (tokenType)
                            {
                                case TokenType.Using:
                                    list.Add(CreateToken(tokenType, _currentStrToken));
                                    break;
                                default:
                                    list.Add(CreateToken(tokenType, _currentStrToken));
                                    break;
                            }
                            CurrentLexState = LexState.None;
                            UndoChar();
                        }
                        break;
                    default:
                        break;
                }
            }
            return list;
        }
    }
}
