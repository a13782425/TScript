﻿using System;
using System.Collections.Generic;
using System.Text;
using TS.Core.Table;

namespace TS.Compiler
{
    /// <summary>
    /// 语法分析,先解析在分析
    /// </summary>
    internal sealed partial class TSParser
    {
        #region 单例

        /// <summary>
        /// 单例
        /// </summary>
        private TSParser()
        {
            _allAssemblyDefDic = new Dictionary<string, AssemblyDef>();
            _allAssemblyNameDic = new Dictionary<string, List<SystemType>>();
            LoadSystemAssembly(typeof(object).Assembly);
            LoadSystemAssembly(typeof(System.Uri).Assembly);
            LoadSystemAssembly(typeof(System.Uri).Assembly);
        }
        private static TSParser _instance = null;
        /// <summary>
        /// 唯一实例
        /// </summary>
        public static TSParser Instance { get { if (_instance == null) _instance = new TSParser(); return _instance; } }

        #endregion

        #region 所有程序集集合

        /// <summary>
        /// 所有程序集的集合
        /// </summary>
        private Dictionary<string, AssemblyDef> _allAssemblyDefDic;
        /// <summary>
        /// 所有程序集的集合
        /// </summary>
        internal Dictionary<string, AssemblyDef> AllAssemblyDefDic { get { return _allAssemblyDefDic; } }
        /// <summary>
        /// 所有命名空间下的名称
        /// </summary>
        private Dictionary<string, List<SystemType>> _allAssemblyNameDic = new Dictionary<string, List<SystemType>>();
        /// <summary>
        /// 所有命名空间下的名称
        /// </summary>
        private Dictionary<string, List<SystemType>> AllAssemblyNameDic { get { return _allAssemblyNameDic; } }

        #endregion

        #region 分析

        private Stack<Token> _allParserStack = new Stack<Token>();

        private Stack<Token> _currentParserStack = new Stack<Token>();

        private AssemblyDef _currentAssemblyDef = null;

        #endregion

        internal void Parser(List<Token> tokenList, ref AssemblyDef assemblyDef)
        {
            int length = tokenList.Count;
            if (!AllAssemblyDefDic.ContainsKey(assemblyDef.Name))
            {
                AllAssemblyDefDic.Add(assemblyDef.Name, assemblyDef);
            }
            _currentAssemblyDef = assemblyDef;
            while (length > 0)
            {
                length--;
                _allParserStack.Push(tokenList[length]);
            }
            ParseStatement();

        }

        private void ParseStatement()
        {
            while (HasMoreTokens())
            {
                Token token = _allParserStack.Pop();
                switch (token.Type)
                {
                    case TokenType.None:
                        break;
                    case TokenType.Using:
                        _currentParserStack.Push(token);
                    BeginUsing: if (HasMoreTokens())
                        {
                            Token t = _allParserStack.Pop();
                            if (t.Type != TokenType.SemiColon)
                            {
                                _currentParserStack.Push(t);
                                goto BeginUsing;
                            }
                        }
                        ParseUsing();
                        break;
                    case TokenType.Finished:
                        break;
                    default:
                        break;
                }
            }
        }

        private void ParseUsing()
        {
            string name = "";
            while (_currentParserStack.Count > 0)
            {
                name = _currentParserStack.Pop().Lexeme + name;
            }
            Console.WriteLine(name);
        }

    }
}
