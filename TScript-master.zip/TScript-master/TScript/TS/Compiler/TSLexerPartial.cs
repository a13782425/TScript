﻿using System;
using System.Collections.Generic;
using System.Text;
using TS.Exception;

namespace TS.Compiler
{
    internal sealed partial class TSLexer
    {
        /// <summary>
        /// 转向下一行
        /// </summary>
        private void IgnoreLine()
        {
            ++_currentLineNum;
            _currentCharNum = 0;
        }
        /// <summary>
        /// 读取字符
        /// </summary>
        /// <returns></returns>
        private char ReadChar()
        {
            if (EndOfSource)
                throw new LexerException("End of source reached.");
            char ch = _currentSourceLines[_currentLineNum][_currentCharNum++];
            if (EndOfLine)
            {
                IgnoreLine();
            }
            return ch;
        }
        /// <summary>
        /// 创建Token
        /// </summary>
        /// <param name="tokenType"></param>
        /// <returns></returns>
        private Token CreateToken(TokenType tokenType)
        {
            return CreateToken(tokenType, _currentChar);
        }
        /// <summary>
        /// 创建Token
        /// </summary>
        /// <param name="tokenType"></param>
        /// <param name="lexeme"></param>
        /// <returns></returns>
        private Token CreateToken(TokenType tokenType, object lexeme)
        {
            CurrentLexState = LexState.None;
            return new Token(tokenType, lexeme, _currentLineNum, _currentCharNum);
        }
        /// <summary>
        /// 是否是有效的字符
        /// </summary>
        /// <param name="ch"></param>
        /// <returns></returns>
        private bool IsIdentifier(char ch)
        {
            return (ch == '_' || char.IsLetterOrDigit(ch));
        }
        /// <summary>
        /// 无效字符异常
        /// </summary>
        /// <param name="ch"></param>
        private void ThrowInvalidCharacterException(char ch)
        {
            throw new LexerException(_currentAssemblyName + ":" + (_currentLineNum + 1) + "  Unexpected character [" + ch + "]  Line:" + (_currentLineNum + 1) + " Column:" + _currentCharNum + " [" + _currentSourceLines[_currentLineNum] + "]");
        }
        private void UndoChar()
        {
            if (_currentLineNum == 0 && _currentCharNum == 0)
                throw new LexerException("Cannot undo char beyond start of source.");
            --_currentCharNum;
            if (_currentCharNum < 0)
            {
                --_currentLineNum;
                _currentCharNum = _currentSourceLines[_currentLineNum].Length - 1;
            }
        }
        /// <summary>
        /// 检查当前字符
        /// </summary>
        /// <param name="_currentChar"></param>
        /// <param name="list"></param>
        private void CheckChar(ref List<Token> list)
        {
            switch (_currentChar)
            {
                case ' ':
                case '\t':
                case '\n':
                case '\r':
                    break;
                case '(':
                    list.Add(CreateToken(TokenType.LeftPar));
                    break;
                case ')':
                    list.Add(CreateToken(TokenType.RightPar));
                    break;
                case '[':
                    list.Add(CreateToken(TokenType.LeftBracket));
                    break;
                case ']':
                    list.Add(CreateToken(TokenType.RightBracket));
                    break;
                case '{':
                    list.Add(CreateToken(TokenType.LeftBrace));
                    break;
                case '}':
                    list.Add(CreateToken(TokenType.RightBrace));
                    break;
                case ';':
                    list.Add(CreateToken(TokenType.SemiColon));
                    break;
                case '\"':
                    CurrentLexState = LexState.String;
                    break;
                case '.':
                    if (_cacheLexState == LexState.Using)
                    {
                        _currentStrToken += _currentChar;
                    }
                    else
                    {
                        CurrentLexState = LexState.PeriodOrParams;
                    }
                    break;
                default:
                    if (_currentChar == '0')
                    {
                        CurrentLexState = LexState.NumberOrHexNumber;
                        _currentStrToken = "";
                    }
                    else if (char.IsDigit(_currentChar))
                    {
                        CurrentLexState = LexState.Number;
                        _currentStrToken = "" + _currentChar;
                    }
                    else if (IsIdentifier(_currentChar))
                    {
                        CurrentLexState = LexState.Identifier;
                        _currentStrToken = "" + _currentChar;
                    }
                    else
                    {
                        ThrowInvalidCharacterException(_currentChar);
                    }
                    break;
            }
        }
    }
}
