﻿using System;
using System.Collections.Generic;
using System.Text;
using TS.Compiler;
using TS.Core.Table;
using TS.Exception;
using TScript.Utils;

namespace TS
{

    public class TScript
    {
        #region 单例

        /// <summary>
        /// 单例
        /// </summary>
        private TScript()
        {
            _allAssemblyDefDic = new Dictionary<string, AssemblyDef>();
        }
        private static TScript _instance = null;
        /// <summary>
        /// 唯一实例
        /// </summary>
        public static TScript Instance { get { if (_instance == null) _instance = new TScript(); return _instance; } }

        #endregion

        #region 属性和字段
        /// <summary>
        /// 默认的程序集名称
        /// </summary>
        private const string DEFAULT_ASSEMBLY_NAME = "DefaultAssemblyName";
        /// <summary>
        /// 所有程序集的集合
        /// </summary>
        private Dictionary<string, AssemblyDef> _allAssemblyDefDic;
        /// <summary>
        /// 所有程序集的集合
        /// </summary>
        internal Dictionary<string, AssemblyDef> AllAssemblyDefDic { get { return _allAssemblyDefDic; } }

        #endregion


        public bool Load(byte[] bytes)
        {
            return true;
        }

        public bool Load(string context)
        {
            return Load(DEFAULT_ASSEMBLY_NAME, context);
        }
        public bool Load(string assemblyName, string context)
        {
            return LoadString(assemblyName, context);
        }

        internal bool LoadString(string assemblyName, string context)
        {
            try
            {
                if (Util.IsNullOrEmpty(context)) return false;
                TSLexer.Instance.Lexer(assemblyName, context);
                return true;
            }
            catch (System.Exception e)
            {
                throw new ScriptException("load buffer [" + context + "] is error : " + e.ToString());
            }
        }
    }
}
