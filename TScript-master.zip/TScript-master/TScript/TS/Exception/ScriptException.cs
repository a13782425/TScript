﻿using System;

namespace TS.Exception
{
    /// <summary>
    /// 脚本异常
    /// </summary>
    public class ScriptException : System.Exception
    {
        public ScriptException(String strMessage) : base(strMessage) { }
    }
}
