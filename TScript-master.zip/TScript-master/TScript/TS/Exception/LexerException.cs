﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Exception
{
    /// <summary>
    /// 语法解析异常
    /// </summary>
    public class LexerException : ScriptException
    {
        public LexerException(String strMessage) : base(strMessage) { }
    }
}
