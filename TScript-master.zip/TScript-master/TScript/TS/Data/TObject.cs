﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TS.Data
{
    internal class TObject
    {
    }
}
